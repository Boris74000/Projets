var typed = new Typed('.ban2', {
    strings: ["Barney Stinson", "Directeur de la commission de recherche à la GNB."],
    typeSpeed: 60,
    startDelay: 30,
    loop: true

});

$(document).ready(function() {
    $(".owl-carousel").owlCarousel({
      items: 1,
      animateOut: 'slideOutDown',
      animateIn: 'flipInX',
      loop: true
    });
});

$(function(){
    $.scrollIt({
        scrollTime: 3000
    });
});

$("#burger").on({
    click: function () {
        $(".navbarr ul").toggleClass("deplacement")
    }
});

$grid = $(".large_portfolio").isotope({
    itemSelector: '.litle_porfolio',
    layoutMode: 'fitRows'
});

$("#all-filter").on("click", function () {
    $grid.isotope({ filter: '*' });
    $("li").removeClass("active");
    $("#all-filter").addClass("active");
    console.log("y1");

});

$("#js-filter").on("click", function () {
    $grid.isotope({ filter: '.js' });
    console.log("y2");
});

$("#css-filter").on("click", function () {
    $grid.isotope({ filter: '.css' });
    $("li").removeClass("active");
    $("#css-filter").addClass("active");
    console.log("y3");
});

$("#php-filter").on("click", function () {
    $grid.isotope({ filter: '.php' });
    console.log("y4");
});